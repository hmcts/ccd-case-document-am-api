package uk.gov.hmcts.reform.ccd.documentam.model.enums;

public enum Classification {
    PUBLIC,PRIVATE,RESTRICTED
}
